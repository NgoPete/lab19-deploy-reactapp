// component này phân loại GET và SET

export const GET_ORIGINALS = " GET_ORIGINALS";
export const GET_TRENDING = "GET_TRENDING";
export const GET_HIGHRATE = "GET_HIGHRATE";
export const GET_ACTION = "GET_ACTION";
export const GET_COMEDY = "GET_COMEDY";
export const GET_HORROR = "GET_HORROR";
export const GET_ROMAN = "GET_ROMAN";
export const GET_DOCUMENT = "GET_DOCUMENT";
export const GET_SEARCH_MOVIES = "GET_SEARCH_MOVIES";

export const SET_MOVIE_DETAIL = "SET_MOVIE_DETAIL";
